import { supabase } from './supabase';

async function diagnose() {
  const tables = ['kids', 'profiles', 'gallery', 'site_settings'];
  for (const table of tables) {
    console.log(`Checking table: ${table}`);
    const { data, error } = await supabase.from(table).select('*').limit(1);
    if (error) {
      console.log(`Error accessing ${table}:`, error.message);
    } else {
      console.log(`Table ${table} accessible. Columns:`, data.length > 0 ? Object.keys(data[0]) : 'Empty');
    }
  }
}

diagnose();
