MATERIAIS DE REFERÊNCIA DO PROJETO

Esta pasta contém capturas de tela e o vídeo de tela que vieram no ZIP original.
Foram preservados para consulta, mas movidos para fora de public/ porque não são referenciados pelo código do aplicativo e não devem ser enviados aos visitantes como parte do site.

Não foram encontrados arquivos separados de prompts no ZIP original.
