# Corações que Acolhe — Lar Esperança

Projeto PWA em React + TypeScript + Vite. Este arquivo ZIP contém o **código-fonte**, não a pasta compilada para envio direto pelo Netlify Drop.

## Configuração do Supabase

No Netlify, cadastre estas variáveis no projeto correto e no contexto de produção:

- `VITE_SUPABASE_URL`: URL do projeto Supabase.
- `VITE_SUPABASE_ANON_KEY`: chave pública `publishable` (ou `anon` legada) do Supabase.

Nunca use uma chave `sb_secret` ou `service_role` no navegador. O código agora exige as variáveis e não possui mais chave secreta de fallback.

## Publicar pelo Netlify conectado ao repositório

- Build command: `npm run build`
- Publish directory: `dist`
- Node.js: use uma versão compatível com Vite 8 (Node.js 20.19+ ou 22.12+).

Depois de configurar as variáveis, faça um novo deploy de produção. O Netlify precisa **compilar** o código; apenas enviar este ZIP de código-fonte pelo Netlify Drop não é suficiente.

## Publicar pelo Netlify Drop

É necessário executar `npm install` e `npm run build` primeiro e enviar o conteúdo da pasta `dist` para o Netlify Drop. A pasta `dist` não foi incluída neste ZIP porque não foi possível instalar as dependências e validar uma compilação neste ambiente.

## Prints e vídeo de referência

Os prints e o vídeo enviados no ZIP original foram preservados em `reference-material/prints-e-videos-de-referencia/`. Eles não são importados pelo código do site e foram retirados de `public/` para evitar que imagens de evidência e um vídeo de aproximadamente 62 MB sejam publicados desnecessariamente.

Não foram encontrados arquivos de prompt independentes no ZIP original. O código-fonte e as instruções deste README foram mantidos separados dos materiais de referência.
